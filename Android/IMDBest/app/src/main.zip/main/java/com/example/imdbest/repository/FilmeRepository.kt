package com.example.imdbest.repository

import com.example.imdbest.api.OmdbApi
import com.example.imdbest.api.RetrofitClient
import com.example.imdbest.model.Filme
import android.util.Log


class FilmeRepository {
    private val api = RetrofitClient.instance.create(OmdbApi::class.java)

    suspend fun buscarFilmes(titulo: String, apiKey: String): List<Filme> {
        val response = api.buscarFilmes(titulo, apiKey)
        Log.d("API_RESPONSE", response.toString())
        return response.Search ?: emptyList()
    }

    suspend fun buscarDetalhesFilme(imdbID: String, apiKey: String): Filme {
        return api.buscarDetalhesFilme(imdbID, apiKey)
    }
}