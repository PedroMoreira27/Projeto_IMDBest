package com.example.imdbest.model

data class ApiResponse(
    val Search: List<Filme>?,
    val totalResults: String?,
    val Response: String?
)