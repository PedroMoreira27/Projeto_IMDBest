package com.example.imdbest.api

import com.example.imdbest.model.ApiResponse
import com.example.imdbest.model.Filme
import retrofit2.http.GET
import retrofit2.http.Query

interface OmdbApi {
    @GET("/")
    suspend fun buscarFilmes(
        @Query("s") titulo: String,
        @Query("apikey") apiKey: String
    ): ApiResponse

    @GET("/")
    suspend fun buscarDetalhesFilme(
        @Query("i") imdbID: String,
        @Query("apikey") apiKey: String
    ): Filme
}