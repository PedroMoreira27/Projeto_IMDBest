package com.example.imdbest.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.LiveData
import com.example.imdbest.model.Filme
import com.example.imdbest.repository.FilmeRepository
import kotlinx.coroutines.launch

class FilmesViewModel : ViewModel() {
    private val repository = FilmeRepository()
    private val _filmes = MutableLiveData<List<Filme>>()
    val filmes: LiveData<List<Filme>> = _filmes

    private val _filmeDetalhado = MutableLiveData<Filme?>()
    val filmeDetalhado: LiveData<Filme?> = _filmeDetalhado

    fun buscarFilmes(titulo: String, apiKey: String) {
        viewModelScope.launch {
            _filmes.value = repository.buscarFilmes(titulo, apiKey)
        }
    }

    fun buscarDetalhesFilme(imdbID: String, apiKey: String) {
        viewModelScope.launch {
            _filmeDetalhado.value = repository.buscarDetalhesFilme(imdbID, apiKey)
        }
    }

    fun limparFilmeDetalhado() {
        _filmeDetalhado.value = null
    }
}