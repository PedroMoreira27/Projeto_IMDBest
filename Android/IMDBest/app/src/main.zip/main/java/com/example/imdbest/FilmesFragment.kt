package com.example.imdbest

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.example.imdbest.viewmodel.FilmesViewModel
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.navigation.fragment.findNavController
// Importação adicionada

class FilmesFragment : Fragment() {

    private val viewModel: FilmesViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_lista_filmes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val searchView = view.findViewById<SearchView>(R.id.searchView)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rvFilmes)
        recyclerView.layoutManager = LinearLayoutManager(requireContext()) // Adicione esta linha
        val adapter = FilmeAdapter { filmeSelecionado ->
            viewModel.buscarDetalhesFilme(filmeSelecionado.imdbID, "f201fb92")
        }

        viewModel.filmeDetalhado.observe(viewLifecycleOwner) { filmeDetalhado ->
            if (filmeDetalhado != null) {
                val action = FilmesFragmentDirections
                    .actionFilmesFragmentToDetalheFragment(
                        titulo = filmeDetalhado.Title,
                        ano = filmeDetalhado.Year,
                        poster = filmeDetalhado.Poster,
                        descricao = filmeDetalhado.Plot ?: "",
                        nota = filmeDetalhado.imdbRating ?: "",
                        genero = filmeDetalhado.Genre ?: "",
                        classificacao = filmeDetalhado.Rated ?: ""
                    )
                findNavController().navigate(action)
                viewModel.limparFilmeDetalhado()
            }
        }
        recyclerView.adapter = adapter

        viewModel.filmes.observe(viewLifecycleOwner) { lista ->
            adapter.submitList(lista)
        }

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (!query.isNullOrBlank()) {
                    viewModel.buscarFilmes(query, "f201fb92")
                }
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })
    }
}