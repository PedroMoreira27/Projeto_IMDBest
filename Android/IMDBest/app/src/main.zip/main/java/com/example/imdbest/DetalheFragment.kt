package com.example.imdbest

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide

class DetalheFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_detalhe, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val titulo = arguments?.getString("titulo")
        val ano = arguments?.getString("ano")
        val poster = arguments?.getString("poster")
        val descricao = arguments?.getString("descricao")
        val nota = arguments?.getString("nota")
        val genero = arguments?.getString("genero")
        val classificacao = arguments?.getString("classificacao")

        view.findViewById<TextView>(R.id.tvTitulo).text = titulo
        view.findViewById<TextView>(R.id.tvAno).text = ano
        view.findViewById<TextView>(R.id.tvDescricao).text = descricao ?: "Descrição não disponível"
        view.findViewById<TextView>(R.id.tvNota).text = "Nota: ${nota ?: "N/A"}"
        view.findViewById<TextView>(R.id.tvGenero).text = "Gênero: ${genero ?: "N/A"}"
        view.findViewById<TextView>(R.id.tvClassificacao).text = "Classificação: ${classificacao ?: "N/A"}"
        Glide.with(this).load(poster).into(view.findViewById(R.id.ivPoster))
    }
}