package com.example.imdbest.model

data class Filme(
    val imdbID: String,
    val Title: String,
    val Year: String,
    val Poster: String,
    val Plot: String?,
    val imdbRating: String?,
    val Genre: String?,
    val Rated: String?
)